<?php
/**
 * Author: Hieu Nguyen
 * Date: 4/15/2022
 * File: footer.php
 * Description:
 */
?>
<br><br><br>
<div id="push"></div>
</div>
<div id="footer"><br>&copy 2015 Kung Fu Panda Media Library. All Rights Reserved.</div>
</body>
</html>