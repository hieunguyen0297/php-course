<?php
/**
 * Author: Hieu Nguyen
 * Date: 4/3/2022
 * File: database_execution_exception.class.php
 * Description: handle error related to database execution
 */

class DatabaseExecutionException extends Exception {}