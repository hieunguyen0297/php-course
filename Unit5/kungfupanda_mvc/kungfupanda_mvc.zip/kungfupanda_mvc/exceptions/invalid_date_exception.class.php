<?php
/**
 * Author: Hieu Nguyen
 * Date: 4/3/2022
 * File: invalid_date_exception.class.php
 * Description: handle invalid date
 */

class InvalidDateException extends Exception {}