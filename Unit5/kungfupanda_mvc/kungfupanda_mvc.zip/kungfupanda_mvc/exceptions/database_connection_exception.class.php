<?php
/**
 * Author: Hieu Nguyen
 * Date: 4/3/2022
 * File: database_connection_exception.class.php
 * Description: handle exception for database connection error
 */

class DatabaseConnectionException extends Exception {}